<!-- Javascript Files
================================================== -->
<script src="frontend/js/plugins.js"></script>
    <script src="frontend/js/designesia.js"></script>

    <!-- Supersized -->
    <script src='frontend/js/supersized/js/supersized.3.2.7.js'></script>
    <script src='frontend/js/supersized/theme/supersized.shutter.min.js'></script>

    
