<?php 
    $identity = $this->db
        ->table("identity")
        ->get();
    //echo $this->db->getLastquery();
    $no = 1;
    foreach ($identity->getResult() as $identity) { 
        if($identity->identity_logo!=""){
            $logo="images/identity_logo/".$identity->identity_logo;
        }else{
            $logo="images/identity_logo/no_image.png";
        }
        if($identity->identity_name!=""){
            $name=$identity->identity_name;
        }else{
            $name="Hotel";
        }
    }
?>
<!-- subheader close -->
            <!-- footer begin -->
            <footer class="no-top pl20 pr20">
                <div class="subfooter">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">&copy; Copyright <?=date("Y");?> - <?=$name;?> Hotel</div>
                            <div class="col-md-6 text-right">
                                <div class="social-icons">
                                    <?php 
                                    $sosmed = $this->db
                                        ->table("sosmed")
                                        ->get();
                                    //echo $this->db->getLastquery();
                                    $no = 1;
                                    foreach ($sosmed->getResult() as $sosmed) {?>
                                        <a href="<?=$sosmed->sosmed_url;?>"><i class="fa fa-<?=strtolower($sosmed->sosmed_name);?> fa-lg"></i></a>
                                    <?php }?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="#" id="back-to-top"></a>
            </footer>
            <!-- footer close -->
        </div>

        <!-- Javascript Files
    ================================================== -->
        <script src="frontend/js/plugins.js"></script>
        <script src="frontend/js/designesia.js"></script>
        <script src='https://www.google.com/recaptcha/api.js' async defer></script>
        <script src="frontend/form.js"></script>
    </body>
</html>