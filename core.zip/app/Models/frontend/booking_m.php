<?php

namespace App\Models\frontend;

use App\Models\core_m;

class booking_m extends core_m
{
    public function data()
    {
        $data = array();
        $data["message"] = "";
        //cek booking
        if ($this->request->getPostGet("booking_id")) {
            $bookingd["booking_id"] = $this->request->getPostGet("booking_id");
        } else {
            $bookingd["booking_id"] = -1;
        }
        $us = $this->db
            ->table("booking")
            ->getWhere($bookingd);
        /* echo $this->db->getLastquery();
        die; */
        $larang = array("log_id", "id", "user_id", "action", "data", "booking_id_dep", "trx_id", "trx_code");
        if ($us->getNumRows() > 0) {
            foreach ($us->getResult() as $booking) {
                foreach ($this->db->getFieldNames('booking') as $field) {
                    if (!in_array($field, $larang)) {
                        $data[$field] = $booking->$field;
                    }
                }
            }
        } else {
            foreach ($this->db->getFieldNames('booking') as $field) {
                $data[$field] = "";
            }
        }

        //upload image 1
        $data['uploadbooking_picture1'] = "";
        if (isset($_FILES['booking_picture1']) && $_FILES['booking_picture1']['name'] != "") {
            // $request = \Config\Services::request();
            $file = $this->request->getFile('booking_picture1');
            $name = $file->getName(); // Mengetahui Nama File
            $originalName = $file->getClientName(); // Mengetahui Nama Asli
            $tempfile = $file->getTempName(); // Mengetahui Nama TMP File name
            $ext = $file->getClientExtension(); // Mengetahui extensi File
            $type = $file->getClientMimeType(); // Mengetahui Mime File
            $size_kb = $file->getSize('kb'); // Mengetahui Ukuran File dalam kb
            $size_mb = $file->getSize('mb'); // Mengetahui Ukuran File dalam mb


            //$namabaru = $file->getRandomName();//define nama fiel yang baru secara acak

            if ($type == 'image/jpg'||$type == 'image/jpeg'||$type == 'image/png') //cek mime file
            {    // File Tipe Sesuai   
                helper('filesystem'); // Load Helper File System
                $direktori = ROOTPATH . 'public\images\booking_picture1'; //definisikan direktori upload            
                $booking_picture1 = str_replace(' ', '_', $name);
                $booking_picture1 = date("H_i_s_") . $booking_picture1; //definisikan nama fiel yang baru
                $map = directory_map($direktori, FALSE, TRUE); // List direktori

                //Cek File apakah ada 
                foreach ($map as $key) {
                    if ($key == $booking_picture1) {
                        delete_files($direktori, $booking_picture1); //Hapus terlebih dahulu jika file ada
                    }
                }
                //Metode Upload Pilih salah satu
                //$path = $this->request->getFile('uploadedFile')->booking($direktori, $namabaru);
                //$file->move($direktori, $namabaru)
                if ($file->move($direktori, $booking_picture1)) {
                    $data['uploadbooking_picture1'] = "Upload Success !";
                    $input['booking_picture1'] = $booking_picture1;
                } else {
                    $data['uploadbooking_picture1'] = "Upload Gagal !";
                }
            } else {
                // File Tipe Tidak Sesuai
                $data['uploadbooking_picture1'] = "Format File Salah !";
            }
        } 

        //delete
        if ($this->request->getPost("delete") == "OK") {  
              
                $this->db
                ->table("booking")
                ->delete(array("booking_id" => $this->request->getPost("booking_id"),"booking_id" =>$this->request->getPost("booking_id")));
                $data["message"] = "Delete Success";
            
        }
        // dd($_POST);
        //insert
        if ($this->request->getPost("create") == "OK") {
            foreach ($this->request->getPost() as $e => $f) {
                if ($e != 'create' && $e != 'booking_id' && $e != 'date') {
                    $input[$e] = $this->request->getPost($e);
                }
            }
            $input["booking_id"] = $this->request->getPost("booking_id");

            $tgl = $this->request->getPost("date");
            $pecahtgl = explode("-",$tgl);
            $input["booking_from"] = date("Y-m-d",strtotime($pecahtgl[0]));
            $input["booking_to"] = date("Y-m-d",strtotime($pecahtgl[1]));
            // dd($input);

            $builder = $this->db->table('booking');
            $builder->insert($input);
            /* echo $this->db->getLastQuery();
            die; */
            $booking_id = $this->db->insertID();

            $data["message"] = "Room Booking Successful";
        }
        //echo $_POST["create"];die;
        //update
        if ($this->request->getPost("change") == "OK") {
            foreach ($this->request->getPost() as $e => $f) {
                if ($e != 'change' && $e != 'booking_picture') {
                    $input[$e] = $this->request->getPost($e);
                }
            }
            $input["booking_id"] = $this->request->getPost("booking_id");
            $this->db->table('booking')->update($input, array("booking_id" => $this->request->getPost("booking_id")));
            $data["message"] = "Update Success";
            //echo $this->db->last_query();die;
        }
        return $data;
    }
}
